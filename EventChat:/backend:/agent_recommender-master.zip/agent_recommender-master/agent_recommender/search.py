from typing import List
from aws_db.agent_recommender_functions.candidate_query import get_id_summary
from langchain.prompts import PromptTemplate
from langchain.embeddings import HuggingFaceEmbeddings
from datetime import datetime, timedelta
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel
from langchain.vectorstores import Pinecone
import pinecone
from data_models import transform_to_full_summary
from agent_recommender.constants import category_subcategory_mapping_dict
from agent_recommender.exceptions import InvalidUserQuery, NothingFound
from agent_recommender.prompt_templates import user_query_transformer_template, query_candidate_consolidation_template
import os
import aws_db
from data_models import PlayerType


pinecone_environment = 'us-east4-gcp'
index_name = 'event-activity-summaries'


class TransformedUserQuery(BaseModel):
    vector_store_query: str
    subcategories: List[str]
    type: str or None

class UuidResponse(BaseModel):
    uuids: List[str]

class VectorStoreQueryCreator():
    vector_store_query_params: TransformedUserQuery
    time_params = {'start_timestamp': datetime.utcnow().timestamp(),
                   'end_timestamp': (datetime.utcnow() + timedelta(
                       days=90)).timestamp()}

    def __init__(self, vector_store_query_params, time_params=None):
        self.vector_store_query_params = vector_store_query_params
        if time_params:
            self.time_params = time_params

    def _map_categories(self):
        subcategories = []
        for category in self.vector_store_query_params.subcategories:
            if category in category_subcategory_mapping_dict:
                subcategories.extend(category_subcategory_mapping_dict[category])
            else:
                subcategories.append(category)
        return subcategories

    def get_vector_store_filter(self):
        # get subcategories for main category
        subcategories = self._map_categories()
        filter_conditions = [
            # filter the event start time
            {"$or": [{"$and": [{"start_timestamp": {"$gte": self.time_params['start_timestamp']}},
                               {"start_timestamp": {"$lte": self.time_params['end_timestamp']}}]},
                     {"start_timestamp": {"$eq": 0}}]},
            # filter the expiration date
            {"$or": [{"expiration_date": {"$eq": 0}},
                     {"expiration_date": {"$gte": self.time_params['start_timestamp']}}]},
            # filter categories
            {"subcategory": {"$in": subcategories}},
            # get type
        ]
        if self.vector_store_query_params.type is not None:
            is_event = True
            if self.vector_store_query_params.type == 'activity':
                is_event = False
            filter_conditions.append({"is_event": {"$eq": is_event}})

        filter = {
            "$and": filter_conditions
        }
        return filter


class CandidateSelector():
    user_query: str
    transformed_user_query: TransformedUserQuery
    candidates = []
    time_params: dict

    def __init__(self, user_query, model, time_params):
        # self._init_pinecone() # check if this takes time and parallelize if needed
        self.user_query = user_query
        self.model = model
        self.time_params = time_params

    def get_candidate_summaries_ids(self):
        self._get_transformed_user_query()
        self._perform_db_search()
        return self.candidates

    def _get_transformed_user_query(self):
        parser = PydanticOutputParser(pydantic_object=TransformedUserQuery)
        prompt = PromptTemplate(
            template=user_query_transformer_template,
            input_variables=["query"],
            partial_variables={"format_instructions": parser.get_format_instructions()}
        )
        self.transformed_user_query = parser.parse(self.model(prompt.format_prompt(query=self.user_query).to_string()))

    def _perform_db_search(self):
        # check if user query was valid --> if the user query is off topic,  {{"vector_store_query":  "" , "subcategories": [], "type": None}} is returned
        if len(self.transformed_user_query.subcategories):
            # we can query the db or vectorstore
            if self.transformed_user_query.vector_store_query != '':
                self._perform_vector_store_search()
            else:
                self._perform_relational_db_search()
        else:
            # invalid query, directly return
            raise InvalidUserQuery()

    def _perform_relational_db_search(self):
        is_event = None
        if self.transformed_user_query.type is not None:
            if self.transformed_user_query.type == 'event':
                is_event = True
            else:
                is_event = False
        aws_db.Setup(secret_key=os.environ['SECRET_KEY'], player_type=PlayerType.SCRAPER,
                             player_name='agent_recommender')
        self.candidates = get_id_summary(subcategory_names=self.transformed_user_query.subcategories, is_event=is_event,
                                         end_date_utc=datetime.fromtimestamp(self.time_params['end_timestamp']),
                                         start_date_utc=datetime.fromtimestamp(self.time_params['start_timestamp']))

    def _perform_vector_store_search(self):
        self._init_pinecone()
        vector_query_creator = VectorStoreQueryCreator(vector_store_query_params=self.transformed_user_query,
                                                       time_params=self.time_params)
        filter = vector_query_creator.get_vector_store_filter()
        embeddings = HuggingFaceEmbeddings()
        docsearch = Pinecone.from_existing_index(index_name, embeddings)
        # TODO decide how many to retrieve
        docs = docsearch.similarity_search(self.user_query, k=10, filter=filter)
        docs = self.clean_up_event_series(docs)
        # there are 3 options when there are too many ids
        # 1. compare the similarity scores (only for vector db)
        # 2. do a parallel openai reduction
        # 3. use aws to bring the ids in order
        for doc in docs:
            self.candidates.append(
                {'id': doc.metadata['id'], 'summary': transform_to_full_summary(doc.page_content, doc.metadata)})

    def _init_pinecone(self):
        # initialize pinecone
        pinecone.init(
            api_key=os.environ['PINECONE_API_KEY'],  # find at app.pinecone.io
            environment=pinecone_environment  # next to api key in console
        )

    def clean_up_event_series(self, docs):
        result = []
        seen = set()
        for d in docs:
            if ((d.metadata['event_series_id'] not in seen)):
                result.append(d)
                if d.metadata['event_series_id'] != '':
                    seen.add(d.metadata['event_series_id'])
        return result


def llm_candidate_selection(user_query: str, model, time_params: dict):
    candidate_selector = CandidateSelector(user_query, model, time_params)
    candidates = candidate_selector.get_candidate_summaries_ids()
    if not len(candidates):
        raise NothingFound()
    if len(candidates) > 10:
        # TODO only temporary solution
        candidates = candidates[:9]
    parser = PydanticOutputParser(pydantic_object=UuidResponse)
    prompt = PromptTemplate(
        template=query_candidate_consolidation_template,
        input_variables=["query", "candidates"],
        partial_variables={"format_instructions": parser.get_format_instructions()}
    )
    consolidation_prompt = prompt.format_prompt(query=user_query, candidates=[d['summary'] for d in candidates])
    output = model(consolidation_prompt.to_string())
    formatted_output = parser.parse(output)
    return output
