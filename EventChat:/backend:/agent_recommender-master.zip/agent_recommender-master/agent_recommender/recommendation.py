

# user preferences creator
# extend table user by user preference summary and updated at (or new table)
# function that counts new likes and updates user preference summary if new likes exceed a threshold
# if user unknown, return request for user summary