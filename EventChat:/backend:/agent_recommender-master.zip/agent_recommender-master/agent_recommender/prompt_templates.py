user_query_transformer_template = """I have user queries as input that are related to free time activities and events. Based on this query, your task is to extract the most important keywords to query a vector database, to choose one or more subcategories and define whether the query matches an event or activity. To find the relevant subcategories, follow this instruction:
Each main category is mapped to several subcategories. For some subcategories examples are given in brackets. It is very important that no potentially matching subcategory is ignored. Therefore, always also include subcategories that are only remotely similar. If you state a main category, all subcategories will be included. This is the categorization:
Entertainment: {{
Comedy & Cabaret
Music Concert
Movie & Planetarium
Music Festival
Musical
Entertainment Show (e.g., magic shows)
Circus
Fair & Amusement Park (e.g., kermess)
Gaming
Carnival
Other Entertainment}},
Nightlife & Clubs: {{
Rave
Hip-Hop Party
Party
LGBTQ
Karaoke
Cocktails & Drinks
Other Nightlife & Clubs}},
Sport & Fun: {{
Fitness
Outdoor (e.g., rafting, climbing, hiking etc.)
Sport Event (user watches sport rather than doing it themselves)
Fun Activities (e.g., go-kart, escape room, sailing etc.)
Dancing (where the user dance themselves rather than just watching)
Other Sport & Fun}},
Attraction, Tours & Trips: {{
Trip & Sightseeing 
Aquarium & Zoo
Attraction (e.g., for tourists or people that like to discover)
Other Attraction, Tours & Trips}},
Retreat & Wellness: {{
Health
Spirituality
Beauty
Fashion
Yoga
Wellness & Spa
Other Retreat & Wellness}},
Food & Tasting: {{
Street-Food
Pop-up Restaurant
Cafe
Restaurant
Tasting (e.g., food or beverages)
Food Festival
Other Food & Tasting}},
Culture & Performing Art: {{
Opera & Operetta
Classic Concert
Theatre
Reading
Poetry Slam
Art Exhibition & Gallery
Museum
Dance & Ballet
Culture Festival
Other Culture & Performing Art}},
Students, Family & Couples: {{
Students
Family
Kids
Couples
Other Students, Family & Couples}},
Exhibition, Community & Workshops: {{
Mass & Religious Happenings
Politics
Community Event
Workshop
Weekly Market
Flea Market
Talk
Conferences & Career Events
Charity
Garden
Other Exhibition, Community & Workshops}},
Miscellaneous: {{
Dating
Shopping
Home 
Other Diverse}}

For defining the keywords, the vector database is queried. Extract further information that goes beyond the categorization. Avoid unnecessary keywords that are not likely to be present in the summaries. Especially, do not query for generic keywords that are included in the categorization except for very specific subcategories such as 'Karaoke', 'Rave', 'Family', 'Kids' etc. Furthermore, do not include negative claims as the vector database will not understand it, e.g. 'List me parties except raves' should be interpreted as no keyword ('').
Here are three representative summaries the keywords will be queried on:
[The activity has the title 'Exitzone Kiel Room Escape'.\nThe activity takes place in Kiel, Göteborgring 87. It is categorized as 'Other Entertainment'. The following list of tags are associated with it: ['Escape Room', 'establishment', 'point_of_interest']. There is no price information available.;
The event has the title 'Eierparty- Ostern im Ben Briggs'.\nThe event takes place at the location 'Ben Briggs' in Kiel, Lange Reihe 21. It is described as: 'Hey Party People, wir feiern am Ostersonntag eine dicke Party im Briggs! Wenn ihr ganz genau sucht, findet ihr vielleicht den ein oder anderen Getränke-Gutschein im Club versteckt ;) Als Vorreiter der Kieler Abipartyszene wollen wir auch diesmal wieder eine legendäre Party feiern, nach dem Profil-Abitur und mitten in den Osterferien! Um 21:00 ist dann Einlass im Ben Briggs, an der langen Reihe 21 in Kiel (zwischen Wunderino-Arena und HBF). ... einem Muttizettel + volljährigem Begleiter mitfeiern, ein Erziehungsbeauftragter kann gleich zwei Minderjährige mit reinnehmen. Also: Tickets besorgen und richtig auf den 09.04. im Briggs freuen!! Wir freuen uns auf euch:) ... '. It is categorized as 'Party'. The following list of tags are associated with it: ['Abiparty', 'Beer', 'Food & Drink', 'Party or Social Gathering']. The event costs 8.00€.;
The activity has the title 'Eco Kart Kiel'.\nThe activity takes place in Kiel, Braunstraße 40. It is categorized as 'Fun Activities'. The following list of tags are associated with it: ['establishment', 'go-kart track', 'point_of_interest']. There is no price information available.]

Also state whether the query rather matches an event or activity. While events are characterized by a start time and end time, activities have a static character and are associated with opening times. If the query could possibly match both, return None for the field.

{format_instructions}

If the user query is completely unrelated to getting recommendations or searching event of leisure activities you should respond with: {{"vector_store_query":  "" , "subcategories": [], "type": None}}

Here are some examples:

User input: "Ich suche eine kinderfreundliche Party in Kiel dieses Wochenende."
{{"vector_store_query":  "kinderfreundlich" , "subcategories": ["Music Festival", "Party",  "Rave",  "Hip-Hop Party", "LGBTQ", "Other Nightlife & Clubs", "Other Diverse", "Kids", " Other Students, Family & Couples"], "type": "event"}}

User input: "Gib mir actionreiche Aktivitäten für meine Familie"
{{"vector_store_query":  "" , "subcategories": ["Outdoor", "Fun Activities", "Other Sport & Fun",  "Aquarium & Zoo",  "Fair & Amusement Park", "Other Diverse"], "type": "activity"}}

User input: "Ich suche ein günstiges asiatisches Restaurant"
{{"vector_store_query":  "asiatisch, günstig" , "subcategories": ["Street-Food", "Pop-up Restaurant", "Restaurant",  "Tasting", "Food Festival",  "Other Food & Tasting", "Other Diverse"], "type": "activity"}}

User input: "Ich suche etwas, wo ich heute Abend mit meinen Freunden hingehen kann."
{{"vector_store_query":  "" , "subcategories": ["Entertainment", "Nightlife & Clubs", "Sport Event",  "Fun Activities", "Dancing",  "Food & Tasting", "Other Diverse", "Culture & Performing Art"], "type":None}}

Now your turn:
User input: '{query}'"""



query_candidate_consolidation_template = """Act as free-time recommendation agent for the German city Kiel. You must understand that you do not have information about any leisure activities or events that are going on in Kiel. All the required information will be stated by the user. Based on the input provided, your task is to extract the 3 best suiting events or activities based on the user query and candidate events and activities.
You must return the uuids of the best matching events or activities as JSON and nothing more.
{format_instructions}
The query of the user is: '{query}'
The candidates are: {candidates}
"""