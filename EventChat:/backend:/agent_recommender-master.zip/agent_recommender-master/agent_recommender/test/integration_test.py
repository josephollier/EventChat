from datetime import datetime, timedelta
from dotenv import load_dotenv
from agent_recommender.agent_recommender import AgentRecommender

load_dotenv()
user_query = 'Ich bin auf der Suche nach einer Aktivität, die ich mit meinen Freunden heute Nachmittag unternehmen kann. Wir sind zwischen 20 und 25 Jahre alt.'
agent_recommender = AgentRecommender(user_id='f95de5d8-0369-4451-afc2-6c18562f0d6e',
                                     time_params={'start_timestamp': datetime.utcnow().timestamp(), 'end_timestamp': (
                                             datetime.utcnow() + timedelta(days=90)).timestamp()}, language='German',
                                     chat_history=[(user_query, None)], is_recommendation=False)
agent_recommender.get_agent_response()
