class InvalidUserQuery(Exception):
    pass

class NothingFound(Exception):
    pass