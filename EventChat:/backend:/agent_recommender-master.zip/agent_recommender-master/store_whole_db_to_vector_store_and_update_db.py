import aws_db
from aws_db.agent_rec_database_interactions.get_event_or_activity_object import get_event_or_activity
from aws_db.llm_summary_update.llm_summary_update import update_llm_summary, get_all_ids
from data_models import Event, SummaryCreator, PlayerType
from datetime import datetime
import pinecone
from langchain.embeddings import HuggingFaceEmbeddings
import os


class EventSummaryMetaData(SummaryCreator):
    id: str
    metadata: dict

    def __init__(self, id, event_or_activity):
        super().__init__(event_or_activity)
        self.id = id

    def _get_metadata(self, summary):
        self.metadata = {}
        is_event = isinstance(self.event_or_activity, Event)
        # this is how langchain stores the original text
        self.metadata["text"] = summary
        self.metadata['is_event'] = is_event
        self.metadata['id'] = self.event_or_activity.id
        # Null is not allowed, therefore give a unique value that can be included in the filters
        self.metadata['start_timestamp'] = datetime.timestamp(
            self.event_or_activity.start_datetime_utc) if is_event else 0
        self.metadata[
            'end_timestamp'] = 0 if not is_event else 0 if self.event_or_activity.end_datetime_utc is None else datetime.timestamp(
            self.event_or_activity.end_datetime_utc)
        self.metadata['expiration_date'] = 0 if is_event else datetime.timestamp(
            self.event_or_activity.expiration_date) if self.event_or_activity.expiration_date else 0
        self.metadata[
            'latitude'] = self.event_or_activity.location.address.latitude if not self.event_or_activity.is_online else 0
        self.metadata[
            'longitude'] = self.event_or_activity.location.address.longitude if not self.event_or_activity.is_online else 0
        self.metadata['event_series_id'] = '' if not is_event else '' if (
        self.event_or_activity.event_series_id is None) else self.event_or_activity.event_series_id
        self.metadata['subcategory'] = self.event_or_activity.subcategory_name


    def get_vector_store_summary_meta_data(self):
        summary = self.get_vector_store_summary()
        self._get_metadata(summary)
        return summary, self.metadata


class LLMSummaryUpdater():
    ids: str

    def __init__(self, ids):
        self.ids = ids
        os.environ['HUGGINGFACEHUB_API_TOKEN'] = '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'
        self.embeddings = HuggingFaceEmbeddings()
        # initialize pinecone
        pinecone.init(
            api_key='58d1e267-4759-4cb4-8056-5a06af7cff9b',  # find at app.pinecone.io
            environment='us-east4-gcp'  # next to api key in console
        )

        index_name = "event-activity-summaries"
        if index_name not in pinecone.list_indexes():
            # we create a new index
            pinecone.create_index(index_name, dimension=768)


        self.index = pinecone.Index(index_name)
        # delete existing vectors
        #self.index.delete(deleteAll=True)

    def _process_and_store_to_vector_db(self, vector_store_summary, metadata):
        embeds = self.embeddings.embed_documents([vector_store_summary])
        self.index.upsert([{'id': metadata['id'], 'values': embeds[0], 'metadata': metadata}])

    def _update_llm_summary(self, id, summary):
        update_llm_summary(summary=summary, id=id)

    def store_summaries(self):
        for id in self.ids:
            event_or_activity = get_event_or_activity(id)
            documentCreator = EventSummaryMetaData(id, event_or_activity)
            vector_store_summary, metadata = documentCreator.get_vector_store_summary_meta_data()
            database_summary = documentCreator.get_database_summary()
            self._process_and_store_to_vector_db(vector_store_summary, metadata)
            self._update_llm_summary(id, database_summary)



# if you already have an index, you can load it like this
# docsearch = Pinecone.from_existing_index(index_name, embeddings)





os.environ['SECRET_KEY'] = 'rdCuGUQLA1IFRtd5tDSY'

setup = aws_db.Setup(secret_key=os.environ['SECRET_KEY'], player_type=PlayerType.SCRAPER,
                     player_name='aws_personalize_updater',
                     )



ids = get_all_ids()

summary_updater = LLMSummaryUpdater(ids=ids)
summary_updater.store_summaries()

